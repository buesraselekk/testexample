# Databricks notebook source
from lib import calculate_features


calculate_features()
