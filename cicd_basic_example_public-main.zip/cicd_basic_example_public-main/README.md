# Basic CI/CD example

### Get started

1. Clone to Databricks Repos
2. Make a change
3. Commit and push
4. Watch code check pipeline
5. Make a pull request
6. Watch integration test pipeline
7. Merge to main
8. Watch deploy to prod
