# don't forget about trailing newline


def calculate_features():
    print("Calculating features")
    return [
        [1, "Alice", 110],
        [2, "Bob", 80],
    ]
